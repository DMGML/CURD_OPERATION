const modal = document.querySelector('.modal-container');
const tbody = document.querySelector('tbody');
const sname = document.querySelector('#name');
const soffice = document.querySelector('#office');
const ssalery = document.querySelector('#salery');
const add = document.querySelector('#add');

let items
let id

function float(edit=false, index=0){
    modal.classList.add('active')

  modal.onclick = e => {
    if (e.target.className.indexOf('modal-container') !== -1) {
      modal.classList.remove('active')
    }
  }

  if (edit) {
    sname.value = items[index].name
    soffice.value = items[index].office
    ssalery.value = items[index].salery
    id = index
  } else {
    sname.value = ''
    soffice.value = ''
    ssalery.value = ''
  }
}


function insertItem(item, index) {

    let tr = document.createElement('tr');

    tr.innerHTML = `
      <td>${item.name}</td>
      <td>${item.office}</td>
      <td>Rs ${item.salery}</td>
      <td>
        <button onclick="editItem(${index})">Edit</button>
      </td>
      <td>
        <button onclick="deleteItem(${index})">Delete</button>
      </td>
    `;
    tbody.appendChild(tr);
}

function editItem(index) {
   float(true,index)
}

function deleteItem(index) {
    items.splice(index, 1)
    setitemsBD()
    loaditems()
}

add.onclick = e => {

    if (sname.value == '' || soffice.value == '' || ssalery.value == '') {
        return;
    }

    e.preventDefault();

    if (id !== undefined) {
        items[id].name = sname.value
        items[id].office = soffice.value
        items[id].salery = ssalery.value
    } else {
        items.push({ 'name': sname.value, 'office': soffice.value, 'salery': ssalery.value });
    }
    setitemsBD();

    modal.classList.remove('active');
    loaditems();
    id = undefined;
}

function loaditems() {
    items = getitemsBD();
    tbody.innerHTML = '';
    items.forEach((item, index) => {
        insertItem(item, index);
    })

}

const getitemsBD = () => JSON.parse(localStorage.getItem('dbfunc')) ?? [];
const setitemsBD = () => localStorage.setItem('dbfunc', JSON.stringify(items));

loaditems();

